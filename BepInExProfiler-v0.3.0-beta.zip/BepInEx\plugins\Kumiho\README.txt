BepInEx Profiler v0.3.0 beta by Kumiho
=======================================
A real-time performance profiler for HoneySelect 2.
Tracks per-plugin Update, LateUpdate, FixedUpdate, Harmony patches, coroutines, and
camera rendering cost — live, with a companion app for deeper analysis and throttling.

> BETA: Works well in testing but edge cases are expected. Please report bugs.


REQUIREMENTS
------------
- BepInEx 5.x (already installed if you have mods)
- Windows 10/11
- .NET Framework 4.8 (ships with Windows 10 1903+ — you almost certainly have it)


INSTALLATION
------------
1. Extract this zip so the BepInEx folder merges with your game's root folder.
   Example: if your game is at D:\HoneySelect2\, extract so that
   BepInExProfiler.dll ends up at D:\HoneySelect2\BepInEx\plugins\Kumiho\BepInExProfiler.dll

2. Launch the game. The companion app (ProfilerApp.exe) opens automatically.
   If it doesn't, check the BepInEx config (F1 in-game) under [BepInEx Profiler]
   and make sure "Auto-Launch Companion App" is enabled.
   You can also launch ProfilerApp.exe manually from BepInEx\plugins\Kumiho\.


IN-GAME OVERLAY
---------------
Ctrl+P    — Toggle the overlay on/off
Ctrl+M    — Toggle move/resize mode (drag the overlay around)
Ctrl+E    — Export a CSV snapshot to Documents\BepInExProfiler\

The overlay shows per-plugin average ms/frame across all tracked sources.
Columns: Total | Update | Late | Fixed | Render | Coro | Harmony

All settings are in the BepInEx Configuration Manager (F1 in-game),
under the [BepInEx Profiler] section:
  - Toggle key, Move key, Export key (all rebindable)
  - UI Scale (0.5x – 3x), Font size (8–20)
  - Rolling window (frames to average, default 60)
  - Auto-launch companion app (on by default)


COMPANION APP (ProfilerApp.exe)
--------------------------------
The companion app connects automatically when the game is running. It has four
panels — click the buttons at the top to show/hide each one.

  ⚡ LIVE
    Full plugin list with sortable columns, sparkline history, cost bars,
    and search/filter. Left-click a row to pin it to the Graph.
    Right-click for a quick throttle menu.

  📈 GRAPH
    Scrolling time-series for up to 6 pinned plugins.

  ⚙ THROTTLE
    Per-plugin throttle controls.
    Buttons: ● (normal) | ÷2 | ÷4 | ÷8 | ÷16 | ✕ (disable)
    Save/load named presets on the right side.
    Sort by Name, Cost, or Status.

  📊 STATS
    Frame budget bar (tracked / untracked / headroom),
    category breakdown, top 10 offenders, and plugin count summary.

Each plugin shows a capability badge:
  [T] — Throttleable. Frame-skip (÷2/÷4/÷8/÷16) works.
  [D] — Disable only. Harmony/coroutine based — only ✕ will stop it.
  [M] — Monitor only. No hooks found, cost tracked but not reducible.

The ⚙ button in the top bar opens a Settings panel for font size,
rolling window, and display filters.

Theme: click the theme button (top right) to switch dark/light.
Layout, panel visibility, and theme are remembered between sessions.


THROTTLING
----------
You can reduce a plugin's frame frequency or disable it without touching any files.

Right-click any row in Live, or use the Throttle panel:
  ● Normal   — runs every frame (default)
  ÷2/4/8/16  — runs every Nth frame (~50%/25%/12%/6% cost)
  ✕ Disable  — stops the plugin entirely
  Reset all  — restores everything to normal in one click

Changes are immediate. Throttled plugins show ÷N in the status column,
disabled plugins show [OFF]. Both are visible in the overlay and the app.

⚠ Some plugins may behave unexpectedly when throttled or disabled.
  If the game acts strangely, use Reset all to restore everything.


FILES
-----
CSV exports:      Documents\BepInExProfiler\profiler_YYYY-MM-DD_HH-MM-SS.csv
Throttle presets: Documents\BepInExProfiler\presets.json
Window settings:  Documents\BepInExProfiler\window.cfg
Log file:         BepInEx\plugins\Kumiho\BepInExProfiler_log.txt
                  (include this when reporting bugs)


KNOWN LIMITATIONS
-----------------
- Plugins that work purely through Harmony patches or coroutines show [D] —
  they can only be disabled, not throttled.
- Camera/graphics components (HS2Graphics, Cinemachine, etc.) appear after a
  short delay on Studio load — they show up as [Cam] entries in the list.
- Some plugins may misbehave after being disabled. Reset all fixes this.


TROUBLESHOOTING
---------------
Companion app not connecting?
  → Wait ~5 seconds after the game finishes loading, then try again.
  → Check BepInExProfiler_log.txt for any errors.

Auto-launch not working?
  → Open F1 config in-game, find [BepInEx Profiler], check Auto-Launch Companion App.
  → Or run ProfilerApp.exe manually from BepInEx\plugins\Kumiho\.

Numbers seem off?
  → Values are rolling averages (default 60 frames). Bursty plugins will show
    low averages — pin them to the Graph panel to see spikes over time.


DISCLAIMER
----------
This tool modifies how plugins execute at runtime. While it doesn't touch game
files or save data, disabling or throttling a plugin mid-session can cause
unexpected behaviour. Use at your own risk. See LICENSE for full terms.


---
Bugs or feedback? Open an issue at: github.com/KumihoArts/BepInExProfiler
