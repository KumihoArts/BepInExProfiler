BepInEx Profiler v0.2.0 by Kumiho
===================================
A real-time performance profiler for HoneySelect 2 (and any BepInEx 5.x Unity game).
Tracks per-plugin Update, LateUpdate, FixedUpdate, Harmony patches, coroutines, and
camera rendering cost — live, with a companion app for deeper analysis.


REQUIREMENTS
------------
- BepInEx 5.x (already installed if you have mods)
- Windows 10/11
- .NET Framework 4.8 (comes with Windows 10/11 — you almost certainly have it)


INSTALLATION
------------
1. Extract this zip so the BepInEx folder merges with your game's ROOT folder.
   Example: if your game is at D:\HoneySelect2\, extract so that
   BepInExProfiler.dll lands at D:\HoneySelect2\BepInEx\plugins\Kumiho\BepInExProfiler.dll

2. Launch the game. The companion app (ProfilerApp.exe) opens automatically.
   If it doesn't, you can launch it manually from BepInEx\plugins\Kumiho\ProfilerApp.exe


IN-GAME OVERLAY
---------------
F7        — Toggle the overlay on/off
F8        — Toggle move/resize mode (drag header, resize corner grip)
F9        — Export a CSV snapshot to BepInEx\plugins\Kumiho\ProfilerExports\

The overlay shows per-plugin average ms/frame across all tracked sources.
Columns: Total | Update | LateUpdate | FixedUpdate | Render | Coro | Harmony

[Untracked] at the bottom shows remaining frame time not attributed to any plugin
(Unity internals, coroutines without wrappers, render pipeline work, etc.)

Settings are in BepInEx Configuration Manager (F1):
  - Toggle key, Move key, Export key
  - UI Scale (0.5x – 3x), Font size
  - Rolling window (frames to average)
  - Auto-launch companion app (on/off)


COMPANION APP (ProfilerApp.exe)
--------------------------------
The companion app connects automatically when the game is running and shows
four toggleable panels — click the panel buttons at the top to show/hide each:

  ⚡ LIVE
    Full plugin list with sortable columns, sparkline history per row,
    cost bar, and search/filter. Left-click a row to pin it to the Graph.
    Right-click for throttle options (see PLUGIN CONTROL below).

  📈 GRAPH
    Scrolling time-series graph for up to 6 pinned plugins.
    Each plugin gets a distinct colour with a fill area.
    Y-axis auto-scales; X-axis = last ~30 seconds.

  ⚙ THROTTLE
    Per-plugin throttle controls without right-clicking.
    Buttons: ● (normal) | ÷2 | ÷4 | ÷8 | ÷16 | ✕ (disable)
    Preset panel on the right — save/load named throttle configurations.
    Sort by Name, Cost, or Status.

  📊 STATS
    Frame budget bar (tracked vs untracked vs headroom),
    category breakdown (Update/Coro/Harmony/etc.),
    top 10 offenders, and plugin count summary.

Layout: 1–4 panels visible at once. Drag splitters to resize.
With 3+ panels: two on top, rest on bottom. With 4: 2×2 grid.

Theme: click ☀ Light / 🌙 Dark to switch. Preference is saved.
Window position, size, and panel layout are remembered between sessions.


PLUGIN CONTROL (throttling)
----------------------------
You can reduce a plugin's Update frequency or disable it entirely — useful
for isolating performance problems or freeing up frame budget temporarily.

Right-click any row in Live, or use the Throttle panel:
  Disable    — sets plugin.enabled = false (Update/Late/Fixed stop running)
  Throttle ÷N — plugin runs every Nth frame instead of every frame
  Normal      — restore to every frame
  Reset all   — restore all plugins at once

Changes take effect immediately in-game. Disabled plugins show [OFF] in
red; throttled plugins show ÷N in amber — in both the overlay and app.

⚠ Some plugins may behave unexpectedly when disabled. If the game acts
  strangely, use "Reset all" to restore everything.


EXPORTS
-------
Plugin exports (F9 or Export CSV button):
  Documents\BepInExProfiler\profiler_YYYY-MM-DD_HH-MM-SS.csv

Preset configurations:
  Documents\BepInExProfiler\presets.json

Window settings:
  Documents\BepInExProfiler\window.cfg

Log file (for bug reports):
  BepInEx\plugins\Kumiho\BepInExProfiler_log.txt


KNOWN LIMITATIONS
-----------------
- Plugins that use coroutines heavily may show their cost under [Untracked]
  rather than attributed to the plugin, depending on how the coroutine is launched.
- Harmony patch cost is measured at the patch wrapper level and may slightly
  overestimate due to instrumentation overhead on very fast patches.
- Camera components (HS2Graphics, Cinemachine, etc.) are patched after a short
  delay on scene load — they appear as [Cam] entries in the list.


TROUBLESHOOTING
---------------
App doesn't connect?
  → Make sure the game is running and the overlay has initialized (wait ~5s after launch).
  → Check BepInExProfiler_log.txt for errors.

Auto-launch not working?
  → Disable and re-enable "Auto-Launch Companion App" in BepInEx config (F1).
  → Or launch ProfilerApp.exe manually from BepInEx\plugins\Kumiho\.

Numbers seem wrong?
  → Values are rolling averages over 60 frames by default.
    Bursty plugins (only active during certain events) will show low averages.
    Use the Graph tab to see spikes over time.


---
Questions or feedback? Find Kumiho on the HS2 modding Discord.
